import 'package:dash_chat_2/dash_chat_2.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';
import 'dart:io';
import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:flutter_tts/flutter_tts.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _controller = TextEditingController();
  List<ChatMessage> messages = [];
  final Gemini gemini = Gemini.instance;

  ChatUser currentUser = ChatUser(id: "currentUser", firstName: "User");
  ChatUser geminiUser = ChatUser(
    id: "geminiUser",
    firstName: "Gemini",
    profileImage:
    "https://seeklogo.com/images/G/google-gemini-logo-A5787B2669-seeklogo.com.png",
  );

  final FlutterTts flutterTts = FlutterTts();
  final double _speechRate = 0.5;
  final double _volume = 1.0;
  final double _pitch = 1.0;
  final String _language = 'en-US';

  List<String> _speechQueue = [];
  bool _isSpeaking = false;

  @override
  void dispose() {
    _controller.dispose();
    flutterTts.stop();
    super.dispose();
  }

  Future<void> _sendMessage(ChatMessage chatMessage) async {
    setState(() {
      messages = [chatMessage, ...messages];
    });
    try {
      String question = chatMessage.text;
      await flutterTts.setLanguage(_language);
      await flutterTts.setSpeechRate(_speechRate);
      await flutterTts.setVolume(_volume);
      await flutterTts.setPitch(_pitch);
      await flutterTts.speak(question);


      flutterTts.setCompletionHandler(() async {
        List<Uint8List>? images;
        if (chatMessage.medias?.isNotEmpty ?? false) {
          try {
            File imageFile = File(chatMessage.medias!.first.url);
            if (await imageFile.exists()) {
              images = [await imageFile.readAsBytes()];
            }
          } catch (error) {
            print("loading image error: $error");
          }
        }
        gemini
            .streamGenerateContent(
          question,
          images: images,
        )
            .listen((event) {
          ChatMessage? lastMessage = messages.firstOrNull;
          String response = event.content?.parts?.fold(
              "", (previous, current) => "$previous ${current.text}") ?? "";
          if (lastMessage != null && lastMessage.user == geminiUser) {
            lastMessage = messages.removeAt(0);
            lastMessage.text += response;
            setState(() {
              messages = [lastMessage!, ...messages];
            });
            _speakResponse(response);
          } else {
            ChatMessage message = ChatMessage(
              user: geminiUser,
              createdAt: DateTime.now(),
              text: response,
            );
            setState(() {
              messages = [message, ...messages];
            });
            _speakResponse(response);
          }
        }, onError: (error) {
          // Print error details
          print("Error streaming content from Gemini: $error");

          // Extract and print URL and other request details if possible
          if (error is GeminiException) {
            print("GeminiException: ${error.message}");
            //print("Status code: ${error.response?.statusCode}");
            //print("Request URL: ${error.response?.request?.url}");
          }
        });
      });
    } catch (e) {
      print("Error sending message to Gemini: $e");
    }
  }

  Future<T> retry<T>(Future<T> Function() operation, {int retries = 3}) async {
    int attempt = 0;
    while (true) {
      try {
        return await operation();
      } catch (e) {
        if (attempt >= retries) {
          rethrow;
        }
        attempt++;
        print("Retrying... Attempt $attempt");
      }
    }
  }

  void _speakResponse(String response) {
    _speechQueue.addAll(_splitTextIntoChunks(response));
    _processSpeechQueue();
  }

  List<String> _splitTextIntoChunks(String text, {int minChunkSize = 50, int maxChunkSize = 200}) {
    List<String> chunks = [];
    int totalLength = text.length;
    int chunkSize = (totalLength / 10).clamp(minChunkSize, maxChunkSize).toInt();  // Dynamic chunk size

    int start = 0;
    while (start < totalLength) {
      int end = start + chunkSize;
      if (end >= totalLength) {
        end = totalLength;
      } else {
        end = text.lastIndexOf(' ', end);
        if (end == -1 || end <= start) {
          end = start + chunkSize;
          if (end > totalLength) end = totalLength;
        }
      }
      chunks.add(text.substring(start, end).trim());
      start = end;
    }
    return chunks;
  }

  void _processSpeechQueue() async {
    if (_isSpeaking || _speechQueue.isEmpty) return;

    _isSpeaking = true;
    String textToSpeak = _speechQueue.removeAt(0);
    await flutterTts.speak(textToSpeak);
    flutterTts.setCompletionHandler(() {
      _isSpeaking = false;
      _processSpeechQueue();
    });
  }

  void _sendMediaMessage() async {
    try {
      ImagePicker picker = ImagePicker();
      XFile? file = await picker.pickImage(
        source: ImageSource.gallery,
      );
      if (file != null) {
        ChatMessage chatMessage = ChatMessage(
          user: currentUser,
          createdAt: DateTime.now(),
          text: "Describe this picture?",
          medias: [
            ChatMedia(
              url: file.path,
              fileName: "",
              type: MediaType.image,
            )
          ],
        );
        _sendMessage(chatMessage);
      }
    } catch (e) {
      print("Error sending media message: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Audio + Live Recording Assistant'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                ChatMessage message = messages[index];
                return ListTile(
                  title: Text(message.text),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      labelText: 'Enter your message',
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      ChatMessage message = ChatMessage(
                        user: currentUser,
                        createdAt: DateTime.now(),
                        text: _controller.text,
                      );
                      _sendMessage(message);
                      _controller.clear();
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.image),
                  onPressed: _sendMediaMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
