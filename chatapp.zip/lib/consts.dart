const String GEMINI_API_KEY = "AIzaSyAhNqBDeBFucTxHjSFDXJ7dZ3yucVxo0IA";
const String TestingDomain = "localhost:5000";
const String ProductionDomain = "example.com";
const String CurrentDomain = TestingDomain;