# chatapp

chatapp

## Steps

Create a flutter project EMPTY
Copy following from the zip file
 -- lib folder (and sub files/folders)
 -- android folder (and sub files/folders)
 -- pubspec.yaml

flutter clean
flutter pub cache clean
flutter pub get
flutter run

launch remote or virtual android phone

type a given question to chat with gemini -- 
and you will see both question and answer -- are returned in audio

