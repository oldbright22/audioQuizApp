package com.example.chatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
